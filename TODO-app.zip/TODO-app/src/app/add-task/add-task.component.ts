import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { AdminModel } from '../Model/Admin';
import { AdminService } from '../Service/admin.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {

  
  //to create new employee or edit it
  @Input() admin: AdminModel;

  // to control update button in form
  @Input() isEditing: boolean;

  @Output() edited = new EventEmitter();

  adminArr:AdminModel[];
  taskToEdit:AdminModel;

  constructor(private adminService:AdminService) { 
    this.adminArr = [];
    this.taskToEdit = new AdminModel()
  }

  delete(index: number) {
    this.adminService.delete(index);
   }

  ngOnInit() {
    this.adminArr = this.adminService.getAdmin();
  }

  edit(name:string)
  {
    this.isEditing = true;
    this.taskToEdit = this.adminService.edit(name);
  }

}
