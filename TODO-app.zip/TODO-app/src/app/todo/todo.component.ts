import { Component, OnInit } from '@angular/core';
import { AdminModel } from '../Model/Admin';
import { AdminService } from '../Service/admin.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})


export class TODOComponent implements OnInit {

  adminArr:AdminModel[];
  taskToEdit:AdminModel;
  isEditing:boolean;

  constructor(private adminService:AdminService) { 
    this.adminArr = [];
    this.taskToEdit = new AdminModel()
  }

  delete(index: number) {
    this.adminService.delete(index);
   }

  ngOnInit() {
    this.adminArr = this.adminService.getAdmin();
  }

  edit(name:string)
  {
    this.isEditing = true;
    this.taskToEdit = this.adminService.edit(name);
  }

  addTask(task:AdminModel){
this.adminService.addTask(task);
  }

}
