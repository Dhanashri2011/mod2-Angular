import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AdminService } from '../Service/admin.service';
import { AdminDataModel } from '../Model/AdminData';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  
  //to create new employee or edit it
  @Input() admin: AdminDataModel;

  // to control update button in form
  @Input() isEditing: boolean;

  @Output() edited = new EventEmitter();

 //initilize it
 constructor(private adminService: AdminService) {
  this.admin = new AdminDataModel();
}

add() {
  this.adminService.add(this.admin);
  this.admin = new AdminDataModel();
  
}

update()
{
  this.isEditing = false;
  this.admin = new AdminDataModel();
  this.edited.emit();
}

  ngOnInit() {
  }

goToHome(){
  this.adminService.goToHome();
  }

}
