import { Injectable } from '@angular/core';
import { AdminModel } from '../Model/Admin';
import { Router } from '@angular/router';
import { AdminDataModel } from '../Model/AdminData';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  adminArr: AdminModel[];

  adminDataArr:AdminDataModel[];
 
  
  constructor(private routes:Router) {
    this.adminArr = [];
    this.adminDataArr=[];
  }

  add(admin: AdminDataModel) {
   
    this.adminDataArr.push(admin);
    this.routes.navigate(['/todo']);
  }

  
  getAdmin() {
    return this.adminArr;
  }

  delete(index: number) {
    this.adminArr.splice(index, 1);
  }

  edit(name:string) {
    return this.adminArr.find(x => x.taskName == name);
  }


  goToHome(){
    this.routes.navigate(['/home']);
  }

  addTask(task: AdminModel) {
    this.adminArr.push(task);
    this.routes.navigate(['/addTask']);  
  }

}
