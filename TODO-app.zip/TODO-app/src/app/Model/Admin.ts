export class AdminModel{

    
   
    public taskName:String;
    public taskStatus:String;
 

}