export class AdminDataModel{

    
    public emailId:String;
    public password:String;

}