import { Component, OnInit } from '@angular/core';
import { UserModel } from '../models/User';
import { Input, Output, EventEmitter } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { NewPassword } from '../models/new-password';
import * as sha1 from 'sha1/sha1';
import { PasswordService } from '../services/password.service';
@Component({
  selector: 'app-newpassword',
  templateUrl: './newpassword.component.html',
  styleUrls: ['./newpassword.component.css']
})
export class NewpasswordComponent implements OnInit {

  user: NewPassword;
  conversionEncryptOutput: string;

   // form controls
   passwordControl = new FormControl('', [
    Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]);
  repeatPasswordControl = new FormControl('', []);

  constructor(private passwordService: PasswordService) {
    this.user = new UserModel();
  }


  ngOnInit() {
  }
   // validate password and confirm password
   validateboth() {
    if (this.user.newPassword !== '') {
      if (this.user.newPassword === this.user.confirmPassword) {
        // password matches
      } else {
        this.repeatPasswordControl.setErrors(Validators.requiredTrue);
      }
    }
  }
  cancel() {
    this.user.newPassword = '';
    this.user.confirmPassword = '';
  }
   // submit new password to db
   submitNewPassword() {
    this.conversionEncryptOutput = sha1(this.user.newPassword);
    this.passwordService.submitNewPassword( this.conversionEncryptOutput).subscribe(
      result => {
        console.log(result);
      },
      error => {
        console.log(error);
      }
    );
  }
}

