import { ProductService } from './../services/product.service';
import { Component, OnInit } from '@angular/core';
import { Product } from '../models/Product';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  products:Product[]=[]
  recommendedProduct: String[] = ["assets/test1.jpg", "assets/test2.jpg", "assets/test3.jpg", "assets/test3.jpg", "assets/test1.jpg",
    "assets/test2.jpg", "assets/test3.jpg", "assets/test2.jpg", "assets/test1.jpg", "assets/test2.jpg"]
  constructor(private productService:ProductService) { }

  ngOnInit() {
    this.productService.getAllProducts().subscribe(
      result=>{
          this.products = result;
          console.log(this.products)
      },err=>{
        console.log(err)
      }
    )
  }

}
