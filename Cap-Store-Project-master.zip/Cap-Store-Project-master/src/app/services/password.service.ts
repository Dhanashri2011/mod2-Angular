import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class PasswordService {
  baseHref = 'http://localhost:8888';
  validateEmail(inputEmail: string) {
    console.log(inputEmail);
    return this.http.post<boolean>(this.baseHref + '/verifyEmail', inputEmail);
  }
  constructor(private http: HttpClient) { }
  verifyPassword(currentPassword: string) {
    console.log(currentPassword);
    return this.http.post<boolean>(this.baseHref + '/add', currentPassword);
  }
  submitNewPassword(newPassword: string) {
    console.log(newPassword);
    return this.http.post<boolean>(this.baseHref + '/add', newPassword);
  }
}
