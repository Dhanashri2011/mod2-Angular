import { AddressModel } from './AddressModel';

export class Order{
    id:number;
    addressFromOrder:AddressModel;
    amount:number;
    date:string;
    couponFromOrder:String;
}