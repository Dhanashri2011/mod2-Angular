export class EditCustomer {
    customerId: number;
    firstname: string;
    lastname: string;
    address: string;
    email: string;
    gender: string;
    dateofbirth: string;
    password: string;
    repeatpassword: string;
  }