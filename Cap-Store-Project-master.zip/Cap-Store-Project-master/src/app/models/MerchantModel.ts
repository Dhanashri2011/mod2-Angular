export class Merchant {

    id: number;
    firstName: String;
    lastName: String;
    email:string;
    contact:string;
  }
