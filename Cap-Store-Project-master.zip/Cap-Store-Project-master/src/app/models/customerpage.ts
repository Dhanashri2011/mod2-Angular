export class Customer {

    id: number;
    firstName: String;
    lastName: String;
    address: String;
    email: String;
    contact:String
  }
