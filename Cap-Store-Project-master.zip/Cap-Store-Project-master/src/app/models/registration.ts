export class Registration {
  firstname: string;
  lastname: string;
  address: string;
  email: string;
  password: string;
  repeatpassword: string;
  gender: string;
  dateofbirth: string;
  contact:string
}
