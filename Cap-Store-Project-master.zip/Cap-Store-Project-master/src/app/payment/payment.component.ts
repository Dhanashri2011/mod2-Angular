import { CheckoutService } from './../services/checkout.service';
import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { PayModel } from "../models/pay";
import { Validators, FormControl } from "@angular/forms";

@Component({
  selector: "app-payment",
  templateUrl: "./payment.component.html",
  styleUrls: ["./payment.component.css"]
})
export class PaymentComponent implements OnInit {
  obj: PayModel;
  toggle: false;

  @Output() addedPayment = new EventEmitter();

  numberControl = new FormControl("", [
    Validators.required
  ]);

  holderControl = new FormControl("", [Validators.required]);

  monthControl = new FormControl("", [Validators.required]);

  yearControl = new FormControl("", [Validators.required]);
  cvvControl = new FormControl("", [
    Validators.required,
    Validators.pattern("[0-9]{3}")
  ]);
  constructor(private checkoutService:CheckoutService) {
    this.obj = new PayModel();
  }

  ngOnInit() {}

  addDetails() {
    this.checkoutService.setCardDetails(this.obj).subscribe(
      res=>{
        console.log(res)
        this.addedPayment.emit()
      },err=>{
        console.log(err)
        this.addedPayment.emit()
      }
    )
  }

  validate(cvv: number) {
    if (this.obj.cvv == cvv) {
      alert("Congratulation!Your Payment is Successfull.");
    } else {
      alert("Invalid CVV entered");
    }
  }
}
