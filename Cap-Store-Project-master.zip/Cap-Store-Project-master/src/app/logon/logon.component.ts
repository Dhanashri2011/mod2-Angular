import { ServiceService } from '../services/service.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';
import * as sha1 from 'sha1/sha1';
import { MatSnackBar } from '@angular/material';

import { Logon } from './../models/logon';

@Component({
  selector: 'app-logon',
  templateUrl: './logon.component.html',
  styleUrls: ['./logon.component.css']
})
export class LogonComponent implements OnInit {
  inputEmail: string;
  conversionEncryptOutput: string;
  logon: Logon;
  hide = true;
  email = new FormControl('', [Validators.required, Validators.email]);
  passwordControl = new FormControl('', [Validators.required]);


  constructor(private service: ServiceService, private router: Router, private snackBar: MatSnackBar) {
    this.logon = new Logon();
  }
  ngOnInit() { }

  // set validaion error message for email
  getErrorMessage() {
    return this.email.hasError('required')
      ? 'Email is required'
      : this.email.hasError('email')
        ? 'Not a valid email'
        : '';
  }
  encryptPassword() {
    // using crypto js

    /*this.conversionEncryptOutput = CryptoJS.AES.encrypt(
      this.logon.password.trim(),
      this.logon.email.trim()
    ).toString();*/

    // using sha1
    this.conversionEncryptOutput = sha1(this.logon.password);
    this.logon.password = this.conversionEncryptOutput;
  }

  sendLoginCredentials() {
    this.encryptPassword();
    this.service.login(this.logon).subscribe(
      result => {
        console.log(result);
        localStorage.setItem("user", JSON.stringify(result));
        this.service.loggedCustomer = result;
        this.service.isLogged = true;
        this.router.navigate(["/"]);
      },
      error => {
        this.logon.password = ""
        this.snackBar.open("Invalid Credentials", "", {
          duration: 4000,
        });
      }
    );
  }
  navigateToForgotPwd() {
    this.router.navigate(['/forgotpassword']);
  }
}
