import { Component } from '@angular/core';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CapStore';

  plainText: string;//password to encrypt
  encryptText: string;//password to decrypt
  username: string;//email at encryption
  usernameDecr: string;//email at decryption
  conversionEncryptOutput: string;//encrypted password 
  conversionDecryptOutput: string;//decrypted password


  constructor() {
  }

  convertText(conversion: string) {
    if (conversion == "encrypt") {
      this.conversionEncryptOutput = CryptoJS.AES.encrypt(this.plainText.trim() , this.username.trim() ).toString()
    }
    else {
      this.conversionDecryptOutput = CryptoJS.AES.decrypt(this.encryptText.trim(), this.usernameDecr.trim() ).toString(CryptoJS.enc.Utf8);
    }
  }
}



