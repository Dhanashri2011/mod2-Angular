import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { StudentModel } from '../Model/student';
import { StudentService } from '../Service/student.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  
   //to create new employee or edit it
   @Input() student:StudentModel;

   // to control update button in form
   @Input() isEditing: boolean;
 
   @Output() edited = new EventEmitter();
  
  constructor(private studService : StudentService) {
    this.student = new StudentModel;
   }

  ngOnInit() {
  }

  insertStud(){
    this.studService.add(this.student);
  }

  update()
  {
    this.isEditing = false;
    this.student = new StudentModel();
    this.edited.emit();
  }
}
