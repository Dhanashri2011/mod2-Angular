import { Component, OnInit } from '@angular/core';
import { StudentService } from '../Service/student.service';
import { StudentModel } from '../Model/student';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  
  studArr:StudentModel[];
  studToEdit:StudentModel;
  isEditing:boolean;

  constructor(private studService:StudentService) { 
    this.studArr = [];
    this.studToEdit = new StudentModel()
  }
  ngOnInit() {
    this.studArr = this.studService.getStud();
  }

  sortStudByName()
  {
    this.studService.sortStudByName();
  }

  edit(id:number)
  {
    this.isEditing = true;
    this.studToEdit = this.studService.edit(id);
  }

  delete(index: number) {
    this.studService.delete(index);
   }

}
