import { Injectable } from '@angular/core';
import { StudentModel } from '../Model/student';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  studArr:StudentModel[];

  constructor(private routes:Router) { 
    this.studArr=[];
  }

  add(stud: StudentModel) {
    stud.studentId = Math.floor(Math.random() * 100);
    this.studArr.push(stud);
    this.routes.navigate(['/display']);
  }

  getStud() {
    return this.studArr;
  }


  edit(id: number) {
    return this.studArr.find(x => x.studentId == id);
  }

  sortStudByName()
  {
    this.studArr.sort((a,b)=>a.studentName.localeCompare(b.studentName.valueOf()));
    return this.studArr;
  }

  
  delete(index: number) {
    this.studArr.splice(index, 1);
  }
}
