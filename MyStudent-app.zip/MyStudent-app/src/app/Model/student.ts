export class StudentModel{

    public studentId:number;
    public studentName:String;
    public studentGender:String;
    public studentBranch:String;
    public studentMarks:number;

}
