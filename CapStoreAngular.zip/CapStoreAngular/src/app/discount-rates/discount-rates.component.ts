import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discount-rates',
  templateUrl: './discount-rates.component.html',
  styleUrls: ['./discount-rates.component.css']
})
export class DiscountRatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
