import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscountRatesComponent } from './discount-rates.component';

describe('DiscountRatesComponent', () => {
  let component: DiscountRatesComponent;
  let fixture: ComponentFixture<DiscountRatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DiscountRatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DiscountRatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
