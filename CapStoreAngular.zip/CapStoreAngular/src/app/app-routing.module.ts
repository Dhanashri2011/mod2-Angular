import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CheckOrdersComponent } from './check-orders/check-orders.component';
import { DiscountRatesComponent } from './discount-rates/discount-rates.component';
import { PutNewPromosComponent } from './put-new-promos/put-new-promos.component';
import { RemoveProductComponent } from './remove-product/remove-product.component';
import { AddProductsComponent } from './add-products/add-products.component';

const routes: Routes = [
  { path: '', redirectTo: '', pathMatch: 'full' },
  { path: 'addProduct', component: AddProductsComponent, pathMatch: 'full' },
  { path: 'removeProduct', component: RemoveProductComponent, pathMatch: 'full' },
  { path: 'checkOrders', component: CheckOrdersComponent, pathMatch: 'full' },
  { path: 'discountRates', component: DiscountRatesComponent, pathMatch: 'full' },
  { path: 'putNewPromos', component: PutNewPromosComponent, pathMatch: 'full' },
  { path: '**', redirectTo: 'checkOrders', pathMatch: 'full' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
