import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-product',
  templateUrl: './remove-product.component.html',
  styleUrls: ['./remove-product.component.css']
})
export class RemoveProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
