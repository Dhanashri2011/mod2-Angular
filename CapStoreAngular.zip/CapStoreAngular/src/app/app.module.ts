import { MaterialModule } from './material.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { RemoveProductComponent } from './remove-product/remove-product.component';
import { AddProductsComponent } from './add-products/add-products.component';
import { CheckOrdersComponent } from './check-orders/check-orders.component';
import { DiscountRatesComponent } from './discount-rates/discount-rates.component';
import { PutNewPromosComponent } from './put-new-promos/put-new-promos.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    AddProductsComponent,
    RemoveProductComponent,
    CheckOrdersComponent,
    DiscountRatesComponent,
    PutNewPromosComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
