import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PutNewPromosComponent } from './put-new-promos.component';

describe('PutNewPromosComponent', () => {
  let component: PutNewPromosComponent;
  let fixture: ComponentFixture<PutNewPromosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PutNewPromosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PutNewPromosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
