import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-put-new-promos',
  templateUrl: './put-new-promos.component.html',
  styleUrls: ['./put-new-promos.component.css']
})
export class PutNewPromosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
