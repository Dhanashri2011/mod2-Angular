import { Component } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import * as sha1 from 'sha1/sha1';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

title = 'CapStore';  
    
username:string;  

password: string;  

conversionEncryptOutput: string;  
 
constructor() {  
}  

//method is used to encrypt the password
convertText(conversion:string) {  
     this.conversionEncryptOutput = sha1(this.password); 
  
}  
}  