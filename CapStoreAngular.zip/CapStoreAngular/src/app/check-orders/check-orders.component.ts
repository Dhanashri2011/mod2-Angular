import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-orders',
  templateUrl: './check-orders.component.html',
  styleUrls: ['./check-orders.component.css']
})
export class CheckOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
